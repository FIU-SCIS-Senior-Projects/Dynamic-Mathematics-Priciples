<?php
include 'core/init.php'; 
include 'includes/overall/header.php'; ?>

<!-- <body style = background:#eee;> -->
<body>

<div class="row">
	<div class="col-md-2"></div>
				
<div class="col-md-8">

		
		<h1><img src="pics/logo2.jpg" alt="img10" width ="300" />About Us</h1>

<div class="row">
	<div class="col-xs-6 col-md-3">
		<a href="#" class="thumbnail">
			<img src="fiu.jpg" alt="..." width= "500" height = "500">
		</a>
	</div> 

	<div class = "row">
		<p class = "lead" aling ="left" >
			Welcome to the Dynamath network! This website is a project for the Computer Science 
			Course of Senior Project at Florida International University to make math enjoyable 
			for people who thought it couldn't be fun by using Fun Facts, History anecdotes, and
			Dynamic Activites.
		</p>
	</div>
	<br>

	<a  class="thumbnail">
		<img src="math.png" alt="..." class = "img-responsive" width = "300"/>
	</a>

	<center><h3> More information, and history</h3></center>
	<div class = "row">
		<div class="col-md-1"></div>
		<p class = "lead"> 
			Florida International University is a vibrant, student-centered 
			public research university,ideally located in Miami, that is worlds 
			ahead in its commitment to learning, research, entrepreneurship, innovation, and creativity.
		</p>
	</div>

	<div class = "row">
		<div class="col-md-1"></div>
		<p class= "lead" >
			The School of Computing and Information Sciences 
			was formed in 1987 from the former Department of Mathematical Sciences. 
			The mission of the School has several dimensions, consistent with the overall mission of the 
			University and consistent with its role as part of the College of Engineering and Computing.
		</p>
	</div>
</div>
</div> 

</body>

<?php include 'includes/overall/footer.php'; ?>
