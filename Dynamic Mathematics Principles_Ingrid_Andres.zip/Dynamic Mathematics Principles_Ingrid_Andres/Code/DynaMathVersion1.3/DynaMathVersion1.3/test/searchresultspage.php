<?php

set_include_path(dirname(__FILE__)."/../");
include 'core/init.php'; 
include 'includes/overall/header.php';

?>

<html>
	<body>
		<br>
		<div class="row">
			<div class="col-md-2"></div>
			<div class="col-md-8">
				<div class="panel panel-default">
					<div class="panel-body">
						<div class="page-header " style = "margin-top:5px; ">
							<h3> Search Results for: </h3>
							<br>
						</div>
						<br>
						<div class="page-body" style = "margin-top:5px; ">
							<p style='font-size:120%'>
								 <font size="4"><a href="">This is title of a page!</a></font> 
								 <br>
								 This is a description for this page.
							</p>
							<br>
							<p style='font-size:120%'>
								 <font size="4"><a href="">This is another title of a page!</a></font> 
								 <br>
								 This is a description for this page.
							</p>
						</div>
						<br>
					</div>
				</div>
			</div>
		</div>
	</body>
</html>