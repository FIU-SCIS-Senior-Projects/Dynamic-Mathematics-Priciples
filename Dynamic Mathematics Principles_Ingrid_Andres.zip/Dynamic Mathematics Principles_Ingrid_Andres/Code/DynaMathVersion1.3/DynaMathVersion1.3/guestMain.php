<!-- <header class="intro-header" style="background-image: url('img/post-bg.jpg')"> -->
    

<?php include 'includes/visitorHeader.php'; ?>



<body>
		<div class="row">
			<div class="col-md-12 jumbotron">
				<div class="text-center">
					<h1>Welcome to Dynamic Mathematic Principles</h1>
					<strong><h2>Dynamic Mathematics Principles is an application to learn mathematics<br>
                       by interacting with our activities fun-facts  and much more! </strong></h2>
				</div>
			</div>
		</div>
<hr />
	<center><h2> Register Or Login</center></h2>
<hr />	


<div class="row">
	<div class = "container">
		<div class = "col-md-6">
	<!-- left item -->
 <!--  <div class="col-sm-2 col-md-4"> -->
    <div class="thumbnail">
      <!-- <img src="pics/register.jpeg" alt="html5" height="180" width="180"> -->
      <div class="caption">
        <h3>Register</h3>
       <center><p><a href="registrationform.php" class="btn btn-primary" role="button">Register Now</center></a></p>
      </div>
    </div>
  </div>
  <!-- center item -->
  <div class="col-md-6">
    <div class="thumbnail">
      <!-- <img src="pics/img4.jpg" alt="img4" height="1600" width="160" > -->
      <div class="caption">
        <h3>Login</h3>
        <center><p><a href="login.php" class="btn btn-primary" role="button" name = "Submit">Login Now</center></a></p>
      </div>
    </div>
  </div>


<hr/>

<center><h2> Learning Experience</center></h2>
<hr/>

<div class="row">
	<!-- left item -->
	<div class="col-sm-6 col-md-4">
		<div class="thumbnail">
			<img src="pics/mathlogo.png"  alt="html5" class="img-responsive" height="80%" width="80%">
			<div class="caption">
				<h3>Acitivity</h3>
				<p>Click here to try our fun activities!</p>
                <p><a href="selectActivity.php" class="btn btn-primary" role="button">View details</a></p>
			</div>
		</div>
	</div>
	<!-- center item -->
	<div class="col-sm-6 col-md-4">
		<div class="thumbnail">
			<img src="pics/mathlogo1.jpeg" alt="img4" class="img-responsive" height="60%" width="65%">
			<div class="caption">
				<h3>Func-facts</h3>
				<p>Click here and learn about some exciting fun facts!</p>
                <p><a href="selectFunFacts.php" class="btn btn-primary" role="button">View details</a></p>
			</div>
		</div>
	</div>
	<!-- right item -->
	<div class="col-sm-6 col-md-4">
		<div class="thumbnail">
			<img src="pics/mathlogo3.png" alt="img6" class="img-responsive" height="60%" width="40%">
			<div class="caption">
				<h3>History</h3>
				<p>This section contains history about cool mathematicians!</p>
                <p><a href="selectHistory.php" class="btn btn-primary" role="button">View details</a></p>
			</div>
		</div>
	</div>

</div> <!-- end of row -->



</div>
</br>
</body>
<?php include 'includes/overall/footer.php';?>
