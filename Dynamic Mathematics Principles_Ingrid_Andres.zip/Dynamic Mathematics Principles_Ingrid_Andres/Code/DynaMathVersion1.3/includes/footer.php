<footer>
	&copy; Florida International University
</footer>