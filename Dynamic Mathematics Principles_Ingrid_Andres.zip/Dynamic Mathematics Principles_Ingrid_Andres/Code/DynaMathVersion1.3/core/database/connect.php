<?php 
/* $connection_error = 'Sorry, we\'re experiencing connection problems.';
$dbConnection = mysqli_connect("localhost", "root", "", "lr");

if(!$dbConnection)
{
   die($connection_error);
} */


/* mysql_connect('localhost', 'root', '');
mysql_select_db('lr') or die($connection_error); */
?>