<?php
//session_id();
session_start();
//error_reporting(0);


require 'core/database/connect.php';
require 'core/functions/general.php';
require 'core/functions/users.php';

$errors = array();
?>