<?php 
include './includes/overall/header.php';
print_r(getcwd ());
?>
<H4 ALIGN=CENTER>
<SCRIPT LANGUAGE="JavaScript">
<!--
/*
	The following JavaScript code can detect whether the jar applet file is located in the same
	directory as this file and, if not, display an error. This error can be useful for helping 
	first-time JavaSketch authors troubleshoot a JavaSketch that is not working correctly. 
	However, if the default location or name of the jar file is altered by changing the 
	parameters in the <APPLET> tag, this JavaScript code will continue to look next to this 
	file for the jar file, which may result in an error message even though the JavaSketch
	is otherwise functioning correctly. Additionally, future browser updates may cause this code
	to display errors incorrectly.

	This code is completely optional--the entire contents of this <SCRIPT> tag can be deleted and
	the JavaSketch will continue to function normally.
*/

if( IsFileMissing( "./jsp5.jar"))
{
	document.write("<p>This JavaSketch may be unusable because the applet file (jsp5.jar) appears to be missing from its proper location. (It should be located in the same directory as this web page on the web server.)</p>");
}

function IsFileMissing( iFileName)
{
	var tFileIsMissing = false;
	var xmlhttp = null;
	/* If the user is viewing this page with an Opera or Chrome browser locally, we return false
		 as we cannot rely on the detection to work correctly and avoid showing the error altogether */
	if (window.location.protocol == "file:")
		if (window.opera || navigator.userAgent.indexOf("Chrome/") > -1)
			return false;
	if (window.ActiveXObject)
	{
		try
		{
			xmlhttp=new ActiveXObject("MSXML2.XMLHTTP.6.0");
		}
		catch(e)
		{
			try
			{
				xmlhttp=new ActiveXObject("MSXML2.XMLHTTP.3.0");
			}
			catch(e)
			{
				return false;
			}
		}
 	}
	else if (window.XMLHttpRequest)
	{
		xmlhttp=new XMLHttpRequest();
	}
	if( xmlhttp != null)
	{
		try{
			xmlhttp.open("HEAD", iFileName += (iFileName.match(/\?/) == null ? "?" : "&") + (new Date()).getTime(), false);
			xmlhttp.send(null);
			tFileIsMissing = !((xmlhttp.status==200) || (xmlhttp.status == 0));
		}
		catch(er){
			tFileIsMissing = true;
		}
	}
	return tFileIsMissing;
}
//-->
</SCRIPT>
<APPLET CODE="GSP.class"  ARCHIVE="jsp5.jar" CODEBASE="." WIDTH=1000 HEIGHT=779 ALIGN=CENTER><PARAM NAME=MinGrammarVersion VALUE=2>
<PARAM NAME=MeasureInDegrees VALUE=1><PARAM NAME=DirectedAngles VALUE=0>
<PARAM NAME=PixelsPerLengthUnit VALUE=37.7953>
<PARAM NAME=BackRed VALUE=255>
<PARAM NAME=BackGreen VALUE=255>
<PARAM NAME=BackBlue VALUE=255>
<PARAM NAME=Construction VALUE="
{1} Point(236,565)[hidden];
{2} Point(875,513)[hidden];
{3} Line(2,1)[color(0,0,128),mediumLine,dashed];
{4} Point(633,214)[hidden];
{5} Parallel(3,4)[color(0,0,128),mediumLine,dashed];
{6} Point on object(5,0.365949)[label('C'),red,mediumPoint];
{7} Point on object(3,0.877104)[label('B'),red,mediumPoint];
{8} Point on object(3,0.650794)[label('A'),red,mediumPoint];
{9} Segment(7,8)[color(0,0,128),mediumLine];
{10} Segment(6,7)[color(0,0,128),mediumLine];
{11} Segment(8,6)[color(0,0,128),mediumLine];
{12} Polygon(8,7,6)[color(255,128,0)];
{13} FixedText(265,164,'The two dashed lines are parallel')[black];
{14} Area(12,392,605,'Area △ABC = ')[black];
">
Please install <a href="http://www.sun.com/getjava">Java</a> (version 1.4 or later) to use JavaSketchpad applets.</APPLET>
</H4>